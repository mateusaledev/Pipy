# image_processing

description.
the package image_processing is used to:
    processing:
        - Histrogram matching 
        - structural similarity
        - resize
    utils:
        - read image
        - save
        - plot image
        - plot result
        - plot histogram


## installation 

use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

''' bash
pip install image_processing
'''

## autor 
Joao Guilherme

##[mit](https://choosealicense.com/licenses/mit/)